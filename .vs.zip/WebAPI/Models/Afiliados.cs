﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class Afiliados
    {
        public int IDAfiliado { get; set; }

        public string Nombre { get; set; }

        public string Apellido { get; set; }

        public string Cedula { get; set; }

        public string Direccion_1 { get; set; }

        public int IDAReferente { get; set; }

 


    }
}
