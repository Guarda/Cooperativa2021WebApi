﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class Department
    {
        public int IDAfiliado { get; set; }

        public string Cedula { get; set; }
    }
}
