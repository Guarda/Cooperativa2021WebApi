﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Response
{
    public static class CodigoRespuesta
    {
        public static Int16 Exito = 1;
        public static Int16 Advertencia = 2;
        public static Int16 Error = 3;
    }
}