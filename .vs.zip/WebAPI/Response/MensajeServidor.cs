﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Response
{
    public static class MensajeServidor
    {
        public static string RegistroObtenidoConExito = "Registro obtenido con éxito";
    }
}
