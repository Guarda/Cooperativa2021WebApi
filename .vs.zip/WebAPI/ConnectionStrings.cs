﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DataBase
{
    public class ConnectionStrings
    {
        public string SICTConnection { get; set; }
    }
}
