﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class Afiliado : AfiliadoBase
    {
        public String Estado { get; set; }
    }
}
