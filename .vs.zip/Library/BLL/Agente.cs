﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BLL
{
    public class Agente : AgenteBase
    {
    }
}
